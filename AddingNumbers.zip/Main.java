public class Main{
    public static void main(String[] args){
        int x;
        for(x = 1; x < 21; x++){
            System.out.println(x);
        }
    }
}